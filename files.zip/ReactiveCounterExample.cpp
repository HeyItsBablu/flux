#include "FlutterUI_Reactive.hpp"

class ReactiveCounter {
private:
    FlutterUI* ui;
    State<int> counter;  // ✅ Reactive state - auto-updates UI!
    
public:
    ReactiveCounter(FlutterUI* app) : ui(app), counter(0, app) {}
    
    void increment() {
        counter.set(counter.get() + 1);  // ✅ UI updates automatically!
        // No setText(), no rebuild() needed!
    }
    
    void decrement() {
        counter.set(counter.get() - 1);  // ✅ Auto-magic!
    }
    
    WidgetPtr build() {
        return Center(
            Column(
                Text("Reactive Counter")
                    ->setFontSize(24)
                    ->setFontWeight(FontWeight::Bold)
                    ->setTextColor(RGB(33, 150, 243))
                    ->setMargin(20),
                
                // ✅ This Text automatically binds to counter state!
                Text(counter)
                    ->setFontSize(48)
                    ->setTextColor(RGB(76, 175, 80))
                    ->setMargin(20),
                
                Row(
                    Button("Decrement", [this]() { decrement(); })
                        ->setBackgroundColor(RGB(244, 67, 54))
                        ->setMargin(10),
                    
                    Button("Increment", [this]() { increment(); })
                        ->setBackgroundColor(RGB(76, 175, 80))
                        ->setMargin(10)
                )
            )
        );
    }
};

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int) {
    FlutterUI app(hInstance);
    ReactiveCounter counterApp(&app);
    
    app.build([&counterApp]() {
        return counterApp.build();
    });
    
    app.createWindow("Reactive Counter - Smart Updates!", 400, 300);
    
    return app.run();
}

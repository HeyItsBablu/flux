#include "FlutterUI_Reactive.hpp"

// ============================================================================
// OLD WAY: Manual Updates
// ============================================================================

class OldCounter {
private:
    FlutterUI* ui;
    int counter = 0;
    WidgetPtr counterText;
    
public:
    OldCounter(FlutterUI* app) : ui(app) {}
    
    void increment() {
        counter++;
        // ❌ Must manually update text
        counterText->setText(std::to_string(counter));
        // ❌ Must manually rebuild
        ui->rebuild();
    }
    
    WidgetPtr build() {
        return Column(
            Text("Old Way (Manual)")
                ->setFontSize(16)
                ->setFontWeight(FontWeight::Bold)
                ->setTextColor(RGB(255, 152, 0)),
            
            (counterText = Text(std::to_string(counter)))
                ->setFontSize(36)
                ->setMargin(10),
            
            Button("Increment", [this]() { increment(); })
                ->setBackgroundColor(RGB(255, 152, 0))
        );
    }
};

// ============================================================================
// NEW WAY: Reactive State
// ============================================================================

class NewCounter {
private:
    FlutterUI* ui;
    State<int> counter;  // ✅ Reactive state
    
public:
    NewCounter(FlutterUI* app) : ui(app), counter(0, app) {}
    
    void increment() {
        counter.set(counter.get() + 1);
        // ✅ That's it! UI updates automatically!
    }
    
    WidgetPtr build() {
        return Column(
            Text("New Way (Reactive)")
                ->setFontSize(16)
                ->setFontWeight(FontWeight::Bold)
                ->setTextColor(RGB(76, 175, 80)),
            
            Text(counter)  // ✅ Auto-binds to state!
                ->setFontSize(36)
                ->setMargin(10),
            
            Button("Increment", [this]() { increment(); })
                ->setBackgroundColor(RGB(76, 175, 80))
        );
    }
};

// ============================================================================
// COMPARISON APP
// ============================================================================

class ComparisonApp {
private:
    FlutterUI* ui;
    OldCounter oldCounter;
    NewCounter newCounter;
    
public:
    ComparisonApp(FlutterUI* app) 
        : ui(app), oldCounter(app), newCounter(app) {}
    
    WidgetPtr build() {
        return Container(
            Column(
                // Header
                Center(
                    Text("State Management Comparison")
                        ->setFontSize(24)
                        ->setFontWeight(FontWeight::Bold)
                        ->setTextColor(RGB(63, 81, 181))
                )->setMargin(20),
                
                Divider()->setMargin(10),
                
                // Side by side comparison
                Row(
                    // Old way
                    Expanded(
                        Card(oldCounter.build())
                            ->setMargin(10),
                        1
                    ),
                    
                    // New way
                    Expanded(
                        Card(newCounter.build())
                            ->setMargin(10),
                        1
                    )
                ),
                
                Divider()->setMargin(10),
                
                // Explanation
                Card(
                    Column(
                        Text("Key Differences:")
                            ->setFontSize(14)
                            ->setFontWeight(FontWeight::Bold)
                            ->setMargin(5),
                        
                        Text("OLD: Manual setText() + rebuild()")
                            ->setFontSize(12)
                            ->setTextColor(RGB(255, 152, 0))
                            ->setMargin(3),
                        
                        Text("NEW: Automatic UI sync with State<T>")
                            ->setFontSize(12)
                            ->setTextColor(RGB(76, 175, 80))
                            ->setMargin(3),
                        
                        SizedBox(0, 10),
                        
                        Text("Performance:")
                            ->setFontSize(14)
                            ->setFontWeight(FontWeight::Bold)
                            ->setMargin(5),
                        
                        Text("OLD: Rebuilds entire UI (slow)")
                            ->setFontSize(12)
                            ->setTextColor(RGB(255, 152, 0))
                            ->setMargin(3),
                        
                        Text("NEW: Updates only changed widget (fast!)")
                            ->setFontSize(12)
                            ->setTextColor(RGB(76, 175, 80))
                            ->setMargin(3)
                    )->setSpacing(0)
                )->setMargin(10)
            )->setCrossAlignment(Alignment::Stretch)
        )->setPadding(20)
            ->setBackgroundColor(RGB(250, 250, 250));
    }
};

// ============================================================================
// MAIN
// ============================================================================

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE, LPSTR, int) {
    FlutterUI app(hInstance);
    ComparisonApp comparisonApp(&app);
    
    app.build([&comparisonApp]() {
        return comparisonApp.build();
    });
    
    app.createWindow("Old vs New - State Management", 700, 500);
    
    return app.run();
}
